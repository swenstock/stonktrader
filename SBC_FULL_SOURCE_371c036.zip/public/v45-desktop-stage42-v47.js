(()=>{
'use strict';
if(!window.matchMedia('(min-width:901px)').matches||window.__sbcDesktopStage42V47)return;window.__sbcDesktopStage42V47=true;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
const LIB='sbcNamedBasketsV47';
function readLib(){try{const x=JSON.parse(localStorage.getItem(LIB)||'[]');return Array.isArray(x)?x:[]}catch(_){return[]}}
function writeLib(x){localStorage.setItem(LIB,JSON.stringify(x.slice(0,50)))}
function selectedRows(){return $$('[data-bb19-range]').map(r=>({symbol:String(r.dataset.bb19Range||'').toUpperCase(),weight:Number(r.value||0)})).filter(x=>x.symbol&&x.weight>0)}
function finalRows(){return $$('.bb19-review-list>div').map(r=>({symbol:clean($('b',r)?.textContent).toUpperCase(),weight:Number(clean($('em',r)?.textContent).replace('%',''))})).filter(x=>x.symbol&&x.weight>0)}
function cashPct(){const txt=clean($('.bb19-final .bb19-pane-head span')?.textContent);const m=txt.match(/using\s+(\d+(?:\.\d+)?)%\s+of available cash/i);return m?Number(m[1]):100}
function snapshot(){const rows=selectedRows();return{rows:rows.length?rows:finalRows(),cashPct:cashPct()}}
function saveDialog(){const snap=snapshot();if(!snap.rows.length)return;document.getElementById('namedBasketSaveV47')?.remove();const o=document.createElement('div');o.id='namedBasketSaveV47';o.className='named-basket-save-v47';o.innerHTML='<section><small>BASKET LIBRARY</small><h3>SAVE PORTFOLIO</h3><p>Name this basket so you can load it again later.</p><input id="namedBasketNameV47" maxlength="40" placeholder="e.g. Mega Cap 5"><footer><button data-save-cancel-v47>CANCEL</button><button data-save-confirm-v47>SAVE PORTFOLIO</button></footer></section>';document.body.appendChild(o);const input=$('#namedBasketNameV47',o);setTimeout(()=>input?.focus(),0);$('[data-save-cancel-v47]',o).onclick=()=>o.remove();o.onclick=e=>{if(e.target===o)o.remove()};$('[data-save-confirm-v47]',o).onclick=()=>{const name=clean(input.value);if(!name){input.focus();return}const lib=readLib().filter(x=>String(x.name).toLowerCase()!==name.toLowerCase());lib.unshift({name,rows:snap.rows,cashPct:snap.cashPct,savedAt:Date.now()});writeLib(lib);o.remove();enhanceBasketLibrary();toast(`SAVED: ${name}`);};}
function toast(text){let t=document.getElementById('basketToastV47');if(!t){t=document.createElement('div');t.id='basketToastV47';t.className='basket-toast-v47';document.body.appendChild(t)}t.textContent=text;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),1800)}
function applySaved(name){const item=readLib().find(x=>x.name===name);if(!item)return;const go=()=>{const desired=new Map((item.rows||[]).map(x=>[String(x.symbol).toUpperCase(),Number(x.weight)]));const deselect=()=>{const b=$('[data-bb19-pick].selected');if(b){b.click();setTimeout(deselect,18);return}add(0)};const syms=[...desired.keys()];const add=i=>{if(i>=syms.length){setTimeout(weights,50);return}const b=$(`[data-bb19-pick="${CSS.escape(syms[i])}"]`);if(b&&!b.classList.contains('selected'))b.click();setTimeout(()=>add(i+1),20)};const weights=()=>{for(const [s,w] of desired){const r=$(`[data-bb19-range="${CSS.escape(s)}"]`);if(!r)continue;r.value=String(w);r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}const cp=$('#bb19CashPct');if(cp&&item.cashPct){cp.value=String(item.cashPct);cp.dispatchEvent(new Event('change',{bubbles:true}))}toast(`LOADED: ${item.name}`)};deselect();};if($('.bb19-final')){$('#bb19Back')?.click();setTimeout(go,100)}else go();}
function selectHtml(){const lib=readLib();return '<option value="">SAVED PORTFOLIOS</option>'+lib.map(x=>`<option value="${String(x.name).replace(/"/g,'&quot;')}">${String(x.name).replace(/[<>&]/g,'')}</option>`).join('')}
function enhanceBasketLibrary(){
  const overlay=$('.bb19-overlay');if(!overlay||overlay.hidden)return;
  const pane=$('.bb19-pane');
  if(pane){
    let bar=$('.named-basket-bar-v47',pane);
    if(!bar){bar=document.createElement('div');bar.className='named-basket-bar-v47';bar.innerHTML='<select data-named-basket-v47></select><button type="button" data-save-basket-v47>SAVE PORTFOLIO</button>';const search=$('.bb19-search',pane);search?search.before(bar):pane.prepend(bar);$('[data-save-basket-v47]',bar).onclick=saveDialog;$('[data-named-basket-v47]',bar).onchange=e=>{if(e.target.value)applySaved(e.target.value)}}
    const s=$('[data-named-basket-v47]',bar);if(s){const val=s.value;s.innerHTML=selectHtml();if([...s.options].some(o=>o.value===val))s.value=val}
  }
  const final=$('.bb19-final');
  if(final){
    let save=$('[data-final-save-v47]',final);
    if(!save){save=document.createElement('button');save.type='button';save.dataset.finalSaveV47='1';save.className='final-save-v47';save.textContent='SAVE PORTFOLIO';const bottom=$('.bb19-bottom',final),back=$('#bb19Back',final);if(bottom&&back)back.after(save);save.onclick=saveDialog;}
    let sel=$('[data-final-library-v47]',final);
    if(!sel){sel=document.createElement('select');sel.dataset.finalLibraryV47='1';sel.innerHTML=selectHtml();sel.onchange=e=>{if(e.target.value)applySaved(e.target.value)};$('.bb19-pane-head',final)?.appendChild(sel);}else sel.innerHTML=selectHtml();
  }
}
function moveInsights(){const cards=$$('body *').filter(x=>/STONKBROKER GAME FILM/i.test(clean(x.textContent))&&x.children.length>0);if(!cards.length)return;let card=cards.sort((a,b)=>clean(a.textContent).length-clean(b.textContent).length)[0];const buttons=$$('button,a').filter(x=>/^INSIGHTS$/i.test(clean(x.textContent))||/ANALYZER/i.test(clean(x.textContent)));const btn=buttons.find(x=>!card.contains(x));if(!btn)return;card.classList.add('game-film-v47');btn.classList.add('game-film-insights-v47');let host=$('.game-film-actions-v47',card);if(!host){host=document.createElement('div');host.className='game-film-actions-v47';card.appendChild(host)}host.appendChild(btn);}
function tradingLayout(){const v=$('#view-portfolio'),hold=$('.holdings-card',v),orders=$('.orders-activity-card',v),chart=$('.chart-trade-card',v);if(!v||!hold||!orders||!chart)return;let grid=$('.trading-workspace-v47',v);if(!grid){grid=document.createElement('div');grid.className='trading-workspace-v47';const anchor=$('.contest-metrics-strip-v46',v)||$('.trade-head',v);anchor?.after(grid)}[hold,orders,chart].forEach(x=>{if(x.parentElement!==grid)grid.appendChild(x)});chart.classList.add('chart-order-split-v47');}
function enlargeBasket(){const b=$('#view-portfolio .quick-ticket-launch');if(b)b.classList.add('quick-ticket-launch-v47')}
function enhance(){enhanceBasketLibrary();moveInsights();tradingLayout();enlargeBasket()}
function start(){enhance();let timer;new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(enhance,80)}).observe(document.body,{childList:true,subtree:true});setInterval(enhance,1200)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();